#!/usr/bin/env python3

import socket
import getpass

# Zehaztu POP zerbitzariaren izena/helbidea eta portua
POP_HELB = 
POP_PORT = 

def recvline(s, removeEOL = True):
	"""s socketetik irakurtzen du lerro jauzi bat (CRLF) jaso arte"""
	line = b''
	CRreceived = False
	while True:
		c = s.recv(1)
		if c == b'':
			raise EOFError('Connection closed by the peer before receiving an EOL.')
		line += c
		if c == b'\r':
			CRreceived = True
		elif c == b'\n' and CRreceived:
			if removeEOL:
				return line[:-2]
			else:
				return line
		else:
			CRreceived = False

if __name__ == '__main__':
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	"""IKASLEAK BETETZEKO:
	TCP konexioa ireki.
	"""

	erab = input('Zein da zure buzoiaren erabiltzaile izena? ')
	pasahitza = getpass.getpass('Zein da pasahitza?')
	"""IKASLEAK BETETZEKO:
	Erabiltzailea kautotu.
	"""
	
	"""IKASLEAK BETETZEKO:
	· Buzoiko mezu kopurua lortu eta pantailaratu.
	· Menua aurkeztu 3. aukera hautatu arte:
		1. Mezua irakurri
		2. Mezua ezabatu
		3. Saioa itxi eta irten
	"""
