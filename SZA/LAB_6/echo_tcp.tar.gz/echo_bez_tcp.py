#!/usr/bin/env python3

import socket, sys

PORT = 50007

# Egiaztatu argumentu bat pasa dela.
if len(sys.argv) != 2:
	print("Erabilera: {} <zerbitzaria>".format(sys.argv[0]))
	exit(1)

"""IKASLEAK BETETZEKO:
Sortu socketa eta konektatu zerbitzariarekin.
"""

print("Sartu bidali nahi duzun mezua (hutsa bukatzeko):")
while True:
	mezua = input()
	if not mezua:
		break
	"""IKASLEAK BETETZEKO:
	Bidali irakurritakoa eta erantzuna jaso.
	Idatzi irteera estandarrean jasotakoa.
	***Gogoratu irakurketa bakarrean erantzun osoa jasoko dugunaren
	bermerik ez dagoela!
	"""
"""IKASLEAK BETETZEKO:
Itxi socketa.
"""

