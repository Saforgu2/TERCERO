#!/usr/bin/env python3

import socket

PORT = 50007

"""IKASLEAK BETETZEKO:
Sortu socket bat, esleitu helbide bat eta ezarri entzute socket
bezala.
"""

while True:
	"""IKASLEAK BETETZEKO:
	Onartu konexio berri bat.
	Bezeroak konexioa itxi arte jaso mezuak eta erantzun datu
	berdinak bidaliz.
	"""
"""IKASLEAK BETETZEKO:
Itxi entzute socketa.
"""

