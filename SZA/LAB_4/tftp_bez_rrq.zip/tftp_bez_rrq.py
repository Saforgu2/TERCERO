#!/usr/bin/env python3

import sys
import socket
import time

NULL  = b'\x00'
RRQ   = b'\x00\x01'
WRQ   = b'\x00\x02'
DATA  = b'\x00\x03'
ACK   = b'\x00\x04'
ERROR = b'\x00\x05'

PORT = 50069
BLOCK_SIZE = 512

def get_file(s, serv_addr, filename):
	start = time.time()

	f = open(filename, 'wb')
	"""IKASLEAK BETETZEKO:
	Bidali fitxategi eskaera mezua (RRQ) zerbitzariari.
	"""
	expected_block = 1
	while True:
		"""IKASLEAK BETETZEKO:
		Jaso zerbitzariaren erantzuna eta ziurtatu kode egokia duela (DATA), bestela amaitu.
		Jasotako bloke zenbakia esperotakoa dela ziurtatu (expected_block), bestela begiztaren hasierara itzuli.
		Idatzi jasotako datuak fitxategian (f).
		Bidali ACK zerbitzariari, dagokion bloke zenbakia adieraziz.
		Blokea BLOCK_SIZE baino txikiagoa bada, azkena da, beraz, irten begiztatik.
		Bestela, inkrementatu expected_block.
		"""

	f.close()
	elapsed = time.time() - start
	print('File received in {:.2e} seconds.'.format(elapsed))

if __name__ == '__main__':
	if len(sys.argv) != 3:
		print('Usage: {} server filename'.format(sys.argv[0]))
		exit(1)

	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	serv_addr = (sys.argv[1], PORT)

	get_file(s, serv_addr, sys.argv[2])
